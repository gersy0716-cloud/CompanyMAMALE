/**
 * 全局配置
 * 所有 API 地址、数据库 ID 和常量集中管理
 */
const Config = {
    // === 当前应用版本号 ===
    CURRENT_VERSION: 'v1.0.2',
    IS_DEV: false, // 开发/测试模式开关

    // === BaseMulti 数据库配置（x-bm-token 认证）===
    DB_API_URL: 'https://data.520ai.cc',
    DB_TOKEN: 'LlrO0TdkBt6AMRiE2KN8FYVJ8Ma1z9jZ7svOpvln',
    DB_BASE_ID: 'bsep0t88MFghCm3xMUU',

    // === 业务 API 配置（Bearer token 认证，用于文件上传等）===
    // ⚠️ EXE 桌面环境无 URL 参数，所有值必须写死
    AUTH_TOKEN: 'eyJhbGciOiJSUzI1NiIsImtpZCI6IkI3RDU5REJCNDFGMjZDNTBENkEyRDE5RDQ3RjI0OThFIiwidHlwIjoiYXQrand0In0.eyJuYmYiOjE3NzE0ODEwNjIsImV4cCI6MTgwMzAxNzA2MiwiaXNzIjoiaHR0cHM6Ly9vYXV0aC5tYW1hbGUudmlwIiwiYXVkIjoiQ29kZUFCQyIsImNsaWVudF9pZCI6IkNvZGVBQkNfQXBwIiwic3ViIjoiMTM5ZGNhMzktNDcwYi0yYjAwLWZkMGEtM2ExNjg5NmUwYTE4IiwiYXV0aF90aW1lIjoxNzcxNDgxMDYxLCJpZHAiOiJsb2NhbCIsInRlbmFudGlkIjoiYzE4NjMyODUtMjVkMS00NGZlLTgwNWMtNWRkZjYxMWY4M2QzIiwicGhvbmVfbnVtYmVyX3ZlcmlmaWVkIjoiRmFsc2UiLCJlbWFpbCI6ImxpY2tpZXNAcXEuY29tIiwiZW1haWxfdmVyaWZpZWQiOiJGYWxzZSIsIm5hbWUiOiJsaWNraWVzIiwiaWF0IjoxNzcxNDgxMDYyLCJzY29wZSI6WyJhZGRyZXNzIiwiQ29kZUFCQyIsImVtYWlsIiwib3BlbmlkIiwicGhvbmUiLCJwcm9maWxlIiwicm9sZSIsIm9mZmxpbmVfYWNjZXNzIl0sImFtciI6WyJwd2QiXX0.jJYy7MVdVo4lojskqguPacNzbyigFrElpYvOsWtK7NJQl9EB5Mrz48IyOgt76BWm2WLKyp9Q0dlg6Fnc4fY6pT81OjfZorJdq7H5dbNuXg42Z6AIMlL0jaBK-rMVjyrB16m3Aorh7t3udzWi6UxZ9TEBe3JT5Zssi3DnFdwg3a5Ag7tu1I1fA9Q-YS8oGze_vcdfaWICGeASBb_gB8aZH9JEtaiU1NJuXGsvCCEkDVqHg4zlUeuFcNBvX3435E4ja41aab29MMf19V4m_9LpyRc3qsB1gP-A6DnSKWJYEFynAZZD3IGzst8TepAkqUXFIA4zQOx6AIUkPBNPpdq9Jw',
    TENANT_ID: 'c1863285-25d1-44fe-805c-5ddf611f83d3',
    USER_ID: '139dca39-470b-2b00-fd0a-3a16896e0a18',
    USER_NAME: '雷君',
    AUTHOR: '官方',
    DB_TYPE: '3w-api', // 用于拼接 BaseURL：https://${type}.520ai.cc/

    // === 数据表 ID（API URL 中使用表ID） ===
    TABLES: {
        USERS: 'injhuCnRig',
        TASKS: 'SxqN1eraUE',
        ACCOUNTS: 'uVB1tBArMg',
        ANNOUNCEMENTS: 'jYb1wcKsHy',
        SKILLS: 'BCHmZn1YSZ',
        DISCUSSIONS: 'gpu3NbzIg9', // 独立讨论表
        GITHUB_PROJECTS: 'rkZxw28qNd',
        CLAUDES: 'N6bAU62sbd', // Claude Code账号表
        MESSAGES: 'messages', // 消息表
        VERSIONS: '3QBYQzM3Hs' // 版本更新表
    },

    NOTIFICATION_POLLING_INTERVAL: 60000, // 轮询频率：1分钟

    // === 任务状态 ===
    TASK_STATUS: ['待接取', '进行中', '待验收', '已完成'],

    // === 任务优先级 ===
    TASK_PRIORITY: ['高', '中', '低'],

    // === 任务类型（主线/支线） ===
    QUEST_TYPES: ['主线', '支线'],

    // === 任务分类 (已移除) ===


    // === 账号类型 ===
    ACCOUNT_TYPES: ['账号密码', 'API Key', '其他'],

    // === 头像颜色池 ===
    AVATAR_COLORS: [
        '#9281FF', '#F53F3F', '#00B42A', '#FF7D00',
        '#165DFF', '#14C9C9', '#F7BA1E', '#D91AD9',
        '#7B61FF', '#0FC6C2', '#F77234', '#6AA1FF'
    ]
};

// === 动态参数注入与环境校验 ===
(function () {
    const urlParams = new URLSearchParams(window.location.search);
    console.log('[Config] 正在初始化环境参数...', window.location.search);

    const map = {
        'token': 'AUTH_TOKEN',   // OAuth Bearer token → 用于文件上传
        'type': 'DB_TYPE',       // 子域名类型 → 拼接 BaseURL
        'tenant': 'TENANT_ID',
        'author': 'AUTHOR',
        'userid': 'USER_ID',
        'username': 'USER_NAME',
        'baseid': 'DB_BASE_ID'
    };

    // 1. 从 localStorage 恢复 (针对 EXE/持久化环境)
    const storedConfig = localStorage.getItem('app_config');
    if (storedConfig) {
        try {
            const parsed = JSON.parse(storedConfig);
            Object.assign(Config, parsed);
            console.log('[Config] 已从缓存加载配置');
        } catch (e) { }
    }

    // 2. 从 URL 注入并更新缓存
    let updated = false;
    const toPersist = {};
    for (const [param, configKey] of Object.entries(map)) {
        const val = urlParams.get(param);
        if (val && val.trim() !== '') {
            Config[configKey] = val;
            toPersist[configKey] = val;
            console.log(`[Config] 参数注入成功: ${configKey} = ${val.length > 15 ? val.substring(0, 8) + '...' : val}`);
            updated = true;
        }
    }

    if (updated) {
        localStorage.setItem('app_config', JSON.stringify({
            ...JSON.parse(localStorage.getItem('app_config') || '{}'),
            ...toPersist
        }));
        console.log('[Config] 已将动态参数持久化到本地');
    }

    // 设置上传模式为云端
    Config.UPLOAD_MODE = 'cloud';
    console.log('[Config] 云端存储模式已就绪');
})();
